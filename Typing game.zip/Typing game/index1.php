<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>


    <meta charset="utf-8">  
    <title>Typing Speed Test With Abhi</title>
    <link rel = "icon" type="image/x-icon" href ="abhi.jpg">
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    h1 {text-align: center;}
    </style>
  </head>
  <body>


    <div class="wrapper">
    <img src ="abhi.jpg" width ="100" height ="80">

    <h1>ABHI TYPING TEST<h1>

      <input type="text" class="input-field">
      <div class="content-box">
        <div class="typing-text">
          <p></p>
        </div>
        <div class="content">
          <ul class="result-details">
            <li class="time">
              <p>Time Left:</p>
              <span><b>60</b>s</span>
            </li>
            <li class="mistake">
              <p>Mistakes:</p>
              <span>0</span>
            </li>
            <li class="wpm">
              <p>WPM:</p>
              <span>0</span>
            </li>
            <li class="cpm">
              <p>CPM:</p>
              <span>0</span>
            </li>
          </ul>
          <button>Try Again</button>
        </div>
      </div>
    </div>

    <script src="paragraphs.js"></script>

  
  </body>
</html>